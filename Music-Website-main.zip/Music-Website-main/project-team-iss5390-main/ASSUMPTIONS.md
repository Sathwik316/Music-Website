1.On clicking the link or clickable images it redirests and opens in the same page.
2.Artistxx-songs.html have the information of total length of that album and navigation bar has artists->albums->songs which on clicking goes back to album page.
3.Artist0x-albums.html have artists->albums which on clicking redirects to artists page in the same webpage.
4.All pages have footer at the bottom with a link to about page.
5.Clickable images hover when cursor is on them.
