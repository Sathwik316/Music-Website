[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-24ddc0f5d75046c5622901739e7c5dd533143b0c8e959d652212380cedb1ea36.svg)](https://classroom.github.com/a/uO3FBJhb)
.
├── ASSUMPTIONS.md
├── README.md
└── src
    ├── 1681046555452-thumbnail.jpeg
    ├── 1.png
    ├── about.html
    ├── artist01-albums.html
    ├── artist02-albums.html
    ├── artist03-albums.html
    ├── artist04-albums.html
    ├── artist05-albums.html
    ├── artist06-albums.html
    ├── artist07-albums.html
    ├── artists11-songs.html
    ├── artists12-songs.html
    ├── artists13-songs.html
    ├── artists14-songs.html
    ├── artists15-songs.html
    ├── artists16-songs.html
    ├── artists21-songs.html
    ├── artists22-songs.html
    ├── artists23-songs.html
    ├── artists24-songs.html
    ├── artists25-songs.html
    ├── artists31-songs.html
    ├── artists32-songs.html
    ├── artists33-sings.html
    ├── artists34-songs.html
    ├── artists35-songs.html
    ├── artists36-songs.html
    ├── artists37-songs.html
    ├── artists41-songs.html
    ├── artists42-songs.html
    ├── artists43-songs.html
    ├── artists44-songs.html
    ├── artists45-songs.html
    ├── artists46-songs.html
    ├── artists47-songs.html
    ├── artists51-songs.html
    ├── artists52-songs.html
    ├── artists53-songs.html
    ├── artists54-songs.html
    ├── artists55-songs.html
    ├── artists56-songs.html
    ├── artists61-songs.html
    ├── artists62-songs.html
    ├── artists63-songs.html
    ├── artists64-songs.html
    ├── artists65-songs.html
    ├── artists66-songs.html
    ├── artists71-songs.html
    ├── artists72-songs.html
    ├── artists73-songs.HTML
    ├── artists74-songs.html
    ├── artists75-songs.html
    ├── artists76-songs.html
    ├── artists77-songs.html
    ├── artists.html
    ├── index.css
    └── index.html

All the pages has navigation bar. Albums can move to artists page using navigation bar.Songs page can move to albums page using the navigation bar. By clicking on the photo of a particular album it redirects to the songs page. Similarly by clicking on the particular  artist it will redirect toalbums page of the artist page. From every page the navigation bar helps to redirect to about page. 

README.md
Displaying README.md.
